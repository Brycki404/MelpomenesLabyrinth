Thanks for downloading my asset pack!
Just in case, if you bought this pack from
anywhere other than https://obsydianx.itch.io/
you bought stolen work! If you did, shoot me
a message and let me know where you found it.
I won't make you buy a copy from me but I
would appreciate it.

License:
CC 4.0
https://creativecommons.org/licenses/by/4.0/